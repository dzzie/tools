//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ICONPRO.RC
//
#define IDS_PROGNAME                    1
#define IDS_FILTERSTRING                1
#define IDS_EXEFILTERSTRING             2
#define IDS_BMPFILTERSTRING             3
#define ID_F_MENUOPTION1                100
#define ID_F_ABOUT                      101
#define ID_F_EXIT                       102
#define ICONPRO_MENU                    400
#define ICONPRO_ICON                    401
#define ICONPRO_ABOUT_DLG               402
#define ICONPRO_ICON1                   402
#define IDD_EXTRACTDLG                  404
#define IDD_ADDFORMATDLG                409
#define ID_FILE_NEW                     500
#define ID_FILE_OPEN                    501
#define ID_FILE_SAVE                    502
#define ID_FILE_SAVEAS                  503
#define ID_EDIT_COPY                    504
#define ID_EDIT_PASTE                   505
#define ID_EDIT_STRETCHPASTE            506
#define ID_EDIT_ADDFORMAT               507
#define ID_EDIT_REMOVEFORMAT            508
#define ID_WINDOW_ARRANGEICONS          509
#define ID_WINDOW_CASCADE               510
#define ID_WINDOW_TILE                  511
#define ID_HELP_ABOUT                   512
#define ID_HELP_CONTENTS                513
#define ID_FILE_CLOSE                   514
#define ID_WINDOW_TILEVERTICAL          515
#define ID_FILE_EXTRACT                 516
#define ID_EDIT_IMPORTBMP               518
#define ID_EDIT_STRETCHIMPORTBMP        519
#define ID_EDIT_EXPORTBMP               520
#define IDC_LIST1                       603
#define IDC_DISPLAYICON                 605
#define ID_WIDTHSLIDER                  609
#define ID_HEIGHTSLIDER                 610
#define ID_COLORSLIDER                  615
#define ID_WIDTHTEXT                    616
#define ID_HEIGHTTEXT                   617
#define IDC_SQUAREONLY                  618
#define IDM_WINDOWCHILD                 700
#define ID_GETNUMFORMATS                701
#define ID_UPDATETITLE                  703
#define ID_HASFILECHANGED               705
#define ID_COLORTEXT                    710
#define IDC_DISPLAYBOX                  -1
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        421
#define _APS_NEXT_COMMAND_VALUE         521
#define _APS_NEXT_CONTROL_VALUE         620
#define _APS_NEXT_SYMED_VALUE           706
#endif
#endif
